package Data;

public class ClassSearch {
	//아직 연동안됨.
	public static void professorSearch(int rowCount, int searchRow, String[][] totalData, String[][] searchData,
			String searchText) {
		//교수명으로 검색
		for (int i = 0; i < rowCount; i++) {
			if (totalData[i][5].equals(searchText)) {
				searchData[searchRow] = totalData[i].clone();
				searchRow++;
			}
		}
	}

	public static void subjectSearch(int rowCount, int searchRow, String[][] totalData, String[][] searchData,
			String searchText) {
		//과목이름으로 검색
		for (int i = 0; i < rowCount; i++) {
			if (totalData[i][3].equals(searchText)) {
				searchData[searchRow] = totalData[i].clone();
				searchRow++;
			}
		}
	}
}
