package Data;

public class ClassSearch {
	//아직 연동안됨.
	public void professorSearch(int rowCount, int searchRow, String[][] totalData, String[][] searchData,int searchHms[][], int searchItime[][],
			String searchText) {
		//교수명으로 검색
		for (int i = 0; i < rowCount; i++) {
			if (totalData[i][5].equals(searchText)) {
				searchData[searchRow] = totalData[i].clone();
				searchRow++;
			}
		}
		//searchItime = ChangeData.changeTimeData(searchRow, searchData);// 수강시간토큰으로나눈데이터
		searchHms = new int[searchRow][6];
		//searchHms = HmsData.makeHmsData(searchHms, searchItime, searchRow);
	}

	public void subjectSearch(int rowCount, int searchRow, String[][] totalData, String[][] searchData,int searchHms[][], int searchItime[][],
			String searchText) {
		//과목이름으로 검색
		for (int i = 0; i < rowCount; i++) {
			if (totalData[i][3].equals(searchText)) {
				searchData[searchRow] = totalData[i].clone();
				searchRow++;
			}
		}
		//searchItime = ChangeData.changeTimeData(searchRow, searchData);// 수강시간토큰으로나눈데이터
		searchHms = new int[searchRow][6];
		//searchHms = HmsData.makeHmsData(searchHms, searchItime, searchRow);
	}
}
