package Image;

import java.awt.Color;
import java.awt.GridBagConstraints;

import javax.swing.JPanel;

public class ClassPanel {
	
	//선택된 과목의 정보를 받아 TimeTable에 들어갈 모양의 Panel을 생성

	private static Color color[] = { Color.yellow, Color.blue, Color.red, Color.green, Color.pink, Color.gray,
			Color.orange };

	public static void insertClassPanel(JPanel timeTablePanel, GridBagConstraints gbc, int selectedDataCol,
			int[][] selectedHms, String[][] selectedData) {

		for (int i = 0; i < selectedDataCol; i++) {
			MakePanel.makeClassPanel(timeTablePanel, gbc, selectedHms[i][0], selectedHms[i][1], selectedHms[i][2],
					selectedData[i][3], color[i]);
			if (selectedHms[i][3] == 0) {

			}

			else{
				MakePanel.makeClassPanel(timeTablePanel, gbc, selectedHms[i][3], selectedHms[i][4], selectedHms[i][5],
						selectedData[i][3], color[i]);}
		}
	}
}
