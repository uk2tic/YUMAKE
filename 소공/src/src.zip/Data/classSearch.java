package Data;

public class classSearch {
	//아직 연동안됨.
	private int searchRow;
	
	public int getSearchRow() {
		return searchRow;
	}

	public void setSearchRow(int searchRow) {
		this.searchRow = searchRow;
	}

	public static void professorSearch(int[][] searchItime, int[][] searchHms,int rowCount, int searchRow, String[][] totalData, String[][] searchData,
			String searchText) {
		//교수명으로 검색
		
		for (int i = 0; i < rowCount; i++) {
			if (totalData[i][5].equals(searchText)) {
				searchData[searchRow] = totalData[i].clone();
				searchRow++;
			}
		}
		searchItime = changeData.changeTimeData(searchRow, searchData);// 수강시간토큰으로나눈데이터
		searchHms = new int[searchRow][6];
		searchHms = hmsData.makeHmsData(searchHms, searchItime, searchRow);
		for(int i=0;i<searchRow;i++){
			for(int j=0;j<10;j++){
				System.out.println("1111"+searchData[i][j]);
			}
		}
		
	}

	public static void subjectSearch(int rowCount, int searchRow, String[][] totalData, String[][] searchData,
			String searchText) {
		//과목이름으로 검색
		for (int i = 0; i < rowCount; i++) {
			if (totalData[i][3].equals(searchText)) {
				searchData[searchRow] = totalData[i].clone();
				searchRow++;
			}
		}
	}
}
