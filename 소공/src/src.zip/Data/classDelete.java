package Data;

import GUI.mainUi;

public class classDelete{

	public static void deleteSelectedData(String[][] selectedData, int row, int selectedDataCol, int colCount) {
		//선택된 과목의 데이터를 delete selectedData
		for (int n = row; n < selectedDataCol; n++) {
			for (int m = 0; m < colCount; m++) {

				if (n == selectedDataCol - 1) {

					selectedData[n][m] = null;
				} else
					selectedData[n][m] = selectedData[n + 1][m];
			}
		}
	}
	
	
	public static void deleteClassHms(int row, int selectedDataCol, int colCount, int[][] selectedHms) {
		//선택된 과목의 데이터를 delete selectedHms
		for (int n = row; n < selectedDataCol; n++) {
			for (int m = 0; m < 6; m++) {

				if (n == selectedDataCol - 1) {

					selectedHms[n][m] = 0;
				} else
					selectedHms[n][m] = selectedHms[n + 1][m];
			}
		}
	}
	
}
