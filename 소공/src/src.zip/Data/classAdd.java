package Data;

import javax.swing.table.DefaultTableModel;

public class classAdd {

	public static void add(String[][] totalData, String[][] selectedData, int[][] classHms, int[][] selectedHms, int row, int selectedDataCol) {
		//totalData, classHms 중 선택된 데이터를 selectedData, selectedHms에 넣어주는 메소드
		for(int i =0;i<10;i++){
			System.out.println("aa  "+totalData[row][i]);
		}
		selectedData[selectedDataCol] = totalData[row].clone();
		selectedHms[selectedDataCol]=classHms[row].clone();
	}
	
	public static void addSearchClass(DefaultTableModel selectedModel, String[] selectedData){
		//검색된 과목을 추가하는 메소드(미완성)
		for(int i =0;i<10;i++){
			System.out.println("addsearch  "+selectedData[i]);
		}
		
		selectedModel.addRow(selectedData);
	}
	
}
