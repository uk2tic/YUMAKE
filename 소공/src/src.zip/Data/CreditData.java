package Data;

public class CreditData {
	//수강학점관련클래스
	public static int addCredit(String[][] selectedData, int selectedDataCol, int selectedCredit){
		//선택된 과목의 학점을 추가
		String credit=selectedData[selectedDataCol][4].trim();
		selectedCredit=selectedCredit+Integer.parseInt(credit);
		return selectedCredit;
	}
	
	public static int deleteCredit(String[][] selectedData, int row, int selectedCredit){
		//선택된 과목의 학점을 삭제
		String credit=selectedData[row][4].trim();
		selectedCredit=selectedCredit-Integer.parseInt(credit);
		return selectedCredit;
	}
	
	public static int resetCredit(int selectedCredit){
		//학점을 초기화
		selectedCredit=0;
		return selectedCredit;
	}

}
