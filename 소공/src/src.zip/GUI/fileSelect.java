package GUI;

import java.io.File;

import javax.swing.JFileChooser;

public class fileSelect {
	
	public static File fileSelect(){
		//파일선택
	      JFileChooser fc = new JFileChooser();
	      File file = null;

	      if (fc.showOpenDialog(null) == JFileChooser.APPROVE_OPTION) {
	         file = fc.getSelectedFile();
	         return file;
	      }
	      return file=null;
	   }

}
