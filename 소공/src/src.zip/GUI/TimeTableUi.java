package GUI;

import java.awt.Graphics2D;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.image.BufferedImage;
import java.io.File;

import javax.imageio.ImageIO;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenuItem;
import javax.swing.JPanel;

import Image.ClassPanel;
import Image.MakePanel;

public class TimeTableUi implements MouseListener, ActionListener {

   // 시간표만들어 주는 클래스

   protected static JPanel timeTablePanel;
   protected static JFrame timeTableFrame;
   protected static GridBagConstraints gbc;

   // private JMenuBar menuBar;
   // private JMenu mnNewMenu;
   private JMenuItem saveImageItem;
   private static Graphics2D g;

   public static void getTimeTable(int selectedDataCol, int[][] selectedHms, String[][] selectedData) {

      timeTableFrame = new JFrame();
      timeTableFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

      timeTablePanel = new JPanel();
      timeTablePanel.setLayout(new GridBagLayout());

      gbc = new GridBagConstraints();
      gbc.anchor = GridBagConstraints.CENTER;
      gbc.fill = GridBagConstraints.BOTH;

      JPanel basePanel = new JPanel(new GridBagLayout());
      JLabel baseLabel = new JLabel();

      ClassPanel.insertClassPanel(timeTablePanel, gbc, selectedDataCol, selectedHms, selectedData);

      gbc.gridwidth = 1;
      gbc.gridheight = 1;
      gbc.weightx = 1;
      gbc.weighty = 1;

      // JMenuBar menuBar = new JMenuBar();
      // timeTableFrame.setJMenuBar(menuBar);
      //
      // JMenu mnNewMenu = new JMenu("파일");
      // menuBar.add(mnNewMenu);
      //
      // saveImageItem = new JMenuItem("이미지 저장");
      // mnNewMenu.add(saveImageItem);
      // saveImageItem.addActionListener(this);

      MakePanel.backGroundPanel(timeTablePanel, gbc, basePanel, baseLabel);

      Image img=timeTablePanel.createImage(null);
      
      timeTableFrame.setContentPane(timeTablePanel);
      timeTableFrame.pack();
      timeTableFrame.setSize(500, 500);
      timeTableFrame.setLocationByPlatform(true);
      timeTableFrame.setVisible(true);

      
      
//      BufferedImage bufferedImage = new BufferedImage(500, 500, BufferedImage.TYPE_INT_RGB);
//      g = (Graphics2D) bufferedImage.getGraphics();
//      g.drawImage(img, 0, 0,this);
//      g.fillRect(0, 0, 500, 500);
//
//      try {
//         // 버퍼 이미지를 파일로 출력한다.
//         File outFile = new File("C:\\Users\\DONG WOOK\\Documents\\test.jpg");
//         ImageIO.write(bufferedImage, "jpg", outFile);
//      } catch (Exception e) {
//         System.out.println(e.getMessage());
//      }
   }

   public void actionPerformed(ActionEvent e) {
      // if(e.getSource()==saveImageItem){
      // System.out.println("세이브아이템");
      // }
   }

   @Override
   public void mouseClicked(MouseEvent e) {

   }

   @Override
   public void mouseEntered(MouseEvent arg0) {
      // TODO Auto-generated method stub
   }

   @Override
   public void mouseExited(MouseEvent arg0) {
      // TODO Auto-generated method stub
   }

   @Override
   public void mousePressed(MouseEvent arg0) {
      // TODO Auto-generated method stub
   }

   @Override
   public void mouseReleased(MouseEvent arg0) {
      // TODO Auto-generated method stub
   }
}