package GUI;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.JComboBox;
import javax.swing.JButton;

public class MyClassUi extends JFrame {

	private JPanel contentPane;
	private JTextField myTimeField;

	private String[] Time = new String[] { "9:00", "9:30", "10:00", "10:30", "11:00", "11:30", "12:00", "12:30",
			"13:00", "13:30", "14:00", "14:30", "15:00", "15:30", "16:00", "16:30", "17:00", "17:30", "18:00", "18:30",
			"19:00", "19:30", "20:00", "20:30", "21:00", "21:30", "22:00", "22:30", "23:00", "23:30", "24:00" };

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					MyClassUi frame = new MyClassUi();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public MyClassUi() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 305, 272);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);

		JLabel lblNewLabel = new JLabel("My Time : ");
		lblNewLabel.setBounds(17, 15, 93, 21);
		contentPane.add(lblNewLabel);

		myTimeField = new JTextField();
		myTimeField.setBounds(106, 12, 156, 27);
		contentPane.add(myTimeField);
		myTimeField.setColumns(10);

		JLabel lblNewLabel_1 = new JLabel("요일 : ");
		lblNewLabel_1.setBounds(17, 51, 60, 21);
		contentPane.add(lblNewLabel_1);

		JComboBox dayCb = new JComboBox();
		dayCb.setBounds(76, 48, 186, 27);
		contentPane.add(dayCb);
		dayCb.addItem("월요일");
		dayCb.addItem("화요일");
		dayCb.addItem("수요일");
		dayCb.addItem("목요일");
		dayCb.addItem("금요일");
		dayCb.addItem("토요일");
		

		JLabel lblNewLabel_2 = new JLabel("시작시간 : ");
		lblNewLabel_2.setBounds(17, 87, 93, 21);
		contentPane.add(lblNewLabel_2);

		JLabel lblNewLabel_3 = new JLabel("종료시간 : ");
		lblNewLabel_3.setBounds(17, 123, 93, 21);
		contentPane.add(lblNewLabel_3);

		JComboBox startTimeCb = new JComboBox();
		startTimeCb.setBounds(106, 84, 156, 27);
		contentPane.add(startTimeCb);
		for (int i = 0; i < 31; i++) {
			startTimeCb.addItem(Time[i]);
		}

		JComboBox finishTimeCb = new JComboBox();
		finishTimeCb.setBounds(106, 120, 156, 27);
		contentPane.add(finishTimeCb);
		for (int i = 0; i < 31; i++) {
			finishTimeCb.addItem(Time[i]);
		}

		JButton btnNewButton = new JButton("추가");
		btnNewButton.setBounds(17, 157, 245, 43);
		contentPane.add(btnNewButton);
	}
}
