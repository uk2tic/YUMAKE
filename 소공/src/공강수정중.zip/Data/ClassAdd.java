
package Data;

import javax.swing.table.DefaultTableModel;

public class ClassAdd {

	public void add(String[][] totalData, String[][] selectedData, int[][] classHms, int[][] selectedHms, int row, int selectedDataCol) {
		//totalData, classHms 중 선택된 데이터를 selectedData, selectedHms에 넣어주는 메소드 
		selectedData[selectedDataCol] = totalData[row].clone();
		selectedHms[selectedDataCol]=classHms[row].clone();
	}
	
	public void setSelectedTable(DefaultTableModel selectedModel, String[] selectedData){	
		selectedModel.addRow(selectedData);
	}
}
